TODO
====

- more/better documentation
- more tests
- add motor rotor inertia to model
- add custom motor to joint models
- add Coriolis matrix computation
- add Lagrangian recursive method (maybe)
- add Link/DH parameters class - Link(alpha=x, a=y, ....)
- support tree robots - use tree to model gear and rotor chain
