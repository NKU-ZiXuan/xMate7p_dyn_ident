Changelog
=========

0.3
---

- Added modified Denavit-Hartenberg convention support (DH convention is now a mandatory parameter to RobotDef)
- Added tests to assert correctness of generated equations