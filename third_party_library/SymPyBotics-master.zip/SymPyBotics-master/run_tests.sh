#!/bin/sh
nosetests --with-doctest --doctest-extension=md $@
